var CandyCounter = function() {
    this.lollipopBin = 0;
    this.jellyBeansBin = 0;
};
CandyCounter.prototype.binRemove = function(name, number) {
    if(name === "Lollipop")
        this.lollipopBin -= number;
    else if(name === "Jelly Bean")
        this.jellyBeansBin -= number;
};
CandyCounter.prototype.bin = function(name) {
    if(name === "Lollipop")
        return this.lollipopBin;
    else if(name === "Jelly Bean")
        return this.jellyBeansBin;
};
CandyCounter.prototype.binAdd = function(name, number) {
    if(name === "Lollipop")
        this.lollipopBin += number;
    else if(name === "Jelly Bean")
        this.jellyBeansBin += number;
};
CandyCounter.prototype.setBin = function(name, number) {
    if(name === "Lollipop")
        this.lollipopBin = number;
    else if(name === "Jelly Bean")
        this.jellyBeansBin = number;
};