describe("Candy counter", function() {
    var candy;
    beforeEach(function() {
        candy = new CandyCounter();
    });

    describe("Lollipop bin", function() {
        it("should be 490 candies in this bin when removes 20 candies from a bin of 510 candies", function() {
            candy.setBin("Lollipop", 510);
            candy.binRemove("Lollipop", 20);
            expect(candy.bin("Lollipop")).toEqual(490);
        });
    });

    describe("Jelly Bean bin", function() {
        it("should be 604 candies in this bin when adds 600 candies to a bin that has 4 candies in it", function() {
            candy.setBin("Jelly Bean", 4);
            candy.binAdd("Jelly Bean", 600);
            expect(candy.bin("Jelly Bean")).toEqual(604);
        });
    });

    describe("Test bin", function() {
        it("should not change 200 candies in Lollipop's bin when Remove 20 candies from 100 candies in Jelly Bean's bin", function() {
            candy.setBin("Lollipop", 200);
            candy.setBin("Jelly Bean", 100);
            candy.binRemove("Jelly Bean", 20);
            expect(candy.bin("Lollipop")).toEqual(200);
        });
    });
});